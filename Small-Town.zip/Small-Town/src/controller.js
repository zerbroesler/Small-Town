function Controller(model) {

}
