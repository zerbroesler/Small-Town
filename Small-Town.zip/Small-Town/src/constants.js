var c = {
	color : {
		backgound : '#101040',
		playarea : 0x32d050,
		shape : 0xd030e0,
		shape2 : 0xd03040,
		brush : 0xc8d020,
		goal : 0xf01010
		
	},
	size : {
		x : 950,
		y : 480
	},
	sizeMin : {
		x : 640,
		y : 320
	},
	sizeMax : {
		x : 2560,
		y : 1280
	},
	grid : {
		x : 20,
		y : 15
	},
	tilesize : {
		x : 32,	
		y : 32
	},
	fieldsize : {
		x: 32 * 20,
		y: 32 * 15
	}


};

