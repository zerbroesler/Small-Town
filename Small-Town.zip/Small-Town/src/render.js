function Render(game, param,tool) {

	return function() {
	};

}
    


